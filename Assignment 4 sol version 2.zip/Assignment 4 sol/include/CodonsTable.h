#ifndef CODONSTABLE_H
#define CODONSTABLE_H

#include <string>
#include <fstream>

using namespace std;

// struct representing a codon of 3 DNA/RNA characters and �\0�
struct Codon
{
  	char value[4];    	    // 4th location for null character
    char AminoAcid;  	    // corresponding AminoAcid according to Table
};

// need to create one object of that class to load the AminoAcids table
// into memory
class CodonsTable
{
  	protected:
        Codon codons[64];
   	public:
 	 	// constructors and destructor
        CodonsTable();
        ~CodonsTable();
        void Print();   //print the table
 	 	// function to load all codons from the given text file
        void LoadCodonsFromFile(string codonsFileName);     //Load Codons from table.
        Codon getAminoAcid(char * value) const;     //Get AminoAcid.
        void setCodon(char * value, char AminoAcid, int index);     //Set Codon.
};

#endif // CODONSTABLE_H
