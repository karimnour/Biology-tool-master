#ifndef DNA_H
#define DNA_H

#include <iostream>
#include <fstream>
#include "Sequence.h"
#include "RNA.h"
#include "Protein.h"

using namespace std;
class RNA;
class Protein;

enum DNA_Type{promoter, motif, tail, noncoding};

class DNA : public Sequence
{
    private:
        DNA_Type type;
        int startIndex;
        int endIndex;
    public:
 	 	// constructors and destructor
        DNA();
        DNA(char * seq);
        DNA(char * seq, DNA_Type atype);
        DNA(const DNA& rhs);
        ~DNA();
        DNA operator + (DNA& rhs);    // Why it gives me an error when return char only without *
        void operator = (const DNA& rhs);   //Deep copy.
        friend bool operator == (DNA& obj1, DNA& obj2);     // Why he refuse 2 argument when I remove friend.
        friend bool operator !=(DNA& obj1, DNA& obj2);  //Operator != overloading.
        friend istream& operator >> (istream& in, DNA& dna_obj);    // Function to overload the >> operator.
        friend ostream& operator << (ostream& out, DNA& dna_obj);   // Function to overload the << operator.
        void Print();   //function to be overridden to print all the DNA information
        void read_from_file(string file_name);  //Read sequence from file.
        void print_in_file(string file_name);    //Print sequence in file.
        // function to convert the DNA sequence to RNA sequence
        // It starts by building the complementary_strand of the current
        // DNA sequence (starting from the startIndex to the endIndex), then,
        // it builds the RNA corresponding to that complementary_strand.
        RNA ConvertToRNA();
 	 	// function to build the second strand/pair of DNA sequence
	    // To build a complementary_strand (starting from the startIndex to
        // the endIndex), convert each A to T, each T to A, each C to G, and
        // each G to C. Then reverse the resulting sequence.

        Protein ConvertToProtein();
        void BuildComplementaryStrand();
};

#endif // DNA_H
