#ifndef PROTEIN_H
#define PROTEIN_H

#include <iostream>
#include "Sequence.h"
#include "DNA.h"

using namespace std;

class DNA;

enum Protein_Type {Hormon, Enzyme, TF, Cellular_Function};

class Protein : public Sequence
{
  	private:
        Protein_Type type;
      public:
 	 	// constructors and destructor
 	 	Protein();
 	 	Protein(char * seq);
 	 	Protein(char * seq, Protein_Type atype);
 	 	~Protein();
 	 	Protein operator + (Protein& rhs);      //Add two Protein sequence.
 	 	void operator = (const Protein& rhs);   //Deep copy.
 	 	friend bool operator == (Protein& obj1, Protein& obj2);     //Operator == overloading.
        friend bool operator !=(Protein& obj1, Protein& obj2);  //Operator != overloading.
        friend istream& operator >> (istream& in, Protein& protein_obj);    // Function to overload the >> operator.
        friend ostream& operator << (ostream& out, Protein& protein_obj);   // Function to overload the << operator.
        void Print();   //function to be overridden to print all the Protein information
        void read_from_file(string file_name);  //Read sequence from file.
        void print_in_file(string file_name);    //Print sequence in file.
 	 	// return an array of DNA sequences that can possibly
        // generate that protein sequence
        DNA* GetDNAStrandsEncodingMe(DNA & bigDNA);
};

#endif // PROTEIN_H
