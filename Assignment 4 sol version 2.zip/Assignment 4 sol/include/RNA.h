#ifndef RNA_H
#define RNA_H

#include <iostream>
#include "Sequence.h"
#include "DNA.h"
#include "Protein.h"
#include "CodonsTable.h"

class CodonsTable;
class DNA;
class Protein;

enum RNA_Type {mRNA, pre_mRNA, mRNA_exon, mRNA_intron};

class RNA : public Sequence
{
    private:
        RNA_Type type;
  	public:
 	 	// constructors and destructor
        RNA();
        RNA(char * seq);
        RNA(char * seq, RNA_Type atype);
        RNA(const RNA& rhs);
        ~RNA();
        RNA operator + (RNA& rhs);      //Add two RNA sequence.
        void operator = (const RNA& rhs);   //Deep copy.
        friend bool operator == (RNA& obj1, RNA& obj2);     //Operator == overloading.
        friend bool operator !=(RNA& obj1, RNA& obj2);  //Operator != overloading.
        friend istream& operator >> (istream& in, RNA& rna_obj);    // Function to overload the >> operator.
        friend ostream& operator << (ostream& out, RNA& rna_obj);   // Function to overload the << operator.
        void Print();   //function to be overridden to print all the RNA information
        void read_from_file(string file_name);  //Read sequence from file.
        void print_in_file(string file_name);    //Print sequence in file.
        // function to convert the RNA sequence into protein sequence
        // using the codonsTable object.
        Protein ConvertToProtein(CodonsTable & table);
        // function to convert the RNA sequence back to DNA
        DNA ConvertToDNA();
};

#endif // RNA_H
