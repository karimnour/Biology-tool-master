#include <iostream>
#include <fstream>
#include <cstring>
#include <string>

#include "CodonsTable.h"

using namespace std ;

//----->> Default constructor <<-----------
CodonsTable::CodonsTable()
{

}

//----->> Parameterized constructor <<----------
CodonsTable::~CodonsTable()
{

}

//----->> print the table <<----------
void CodonsTable::Print()
{
    for(int i=0 ; i<64 ; i++)
    {
        for(int y=0 ; y<4 ; y++)
        {
            cout << codons[i].value[y];
        }
        cout << "      ";
        cout << codons[i].AminoAcid;
        cout << endl;
    }
}

//----->> Load Codons from table <<----------
void CodonsTable::LoadCodonsFromFile(string codonsFileName)
{
	ifstream file; // file to read.
    file.open(codonsFileName.c_str(), ios::in); // open the file

    if (!file) // check there error in file.
        cout<<"error loading file\n";
    else
    {
        string line;
        int k = 0;
        while (!file.eof()) // while file not ended.
        {
            getline(file,line); //read from file

            if (line.length()==5) // if there is two space.
            {
                for(int i=0; i<4; i++)
                {
                    codons[k].value[i]=line[i];
                }
                codons[k].AminoAcid=line[4];
                k++;
            }
            else
            {
                for(int i=0; i<4; i++) // if there is one space
                {
                    codons[k].value[i]=line[i];
                }
                codons[k].AminoAcid=line[3];
                k++;

            }
        }

    }
}

//----->> Get AminoAcid <<----------
Codon CodonsTable::getAminoAcid(char* value) const
{
    int i;
    for (i=0; i<64; i++)
    {
        if (value[0]==codons[i].value[0]&& value[1]==codons[i].value[1]&& value[2]==codons[i].value[2])
            break;
    }
    return codons[i];
}

//----->> Set Codon <<----------
void CodonsTable::setCodon(char * value, char AminoAcid, int index)
{
    for(int i=0 ; i<3 ; i++)
    {
        codons[index].value[i] = value[i];
    }
    codons[index].value[3] = '\0';
    codons[index].AminoAcid = AminoAcid;
}
