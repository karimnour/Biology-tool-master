#include "DNA.h"

#include <iostream>


using namespace std;

//----->> Default constructor <<-----------
DNA::DNA()
{
    seq = new char[50];
}

//----->> Parameterized constructor <<----------
DNA::DNA(char * seq)
:Sequence(strlen(seq))
{
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        this->seq[i] = seq[i];
}

//------->> Parameterized constructor <<-----------
DNA::DNA(char* seq, DNA_Type atype)
:Sequence(strlen(seq))
{
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        this->seq[i] = seq[i];
    type = atype;
}

//----->> Copy constructor <<-----------
DNA::DNA(const DNA& rhs)
:Sequence(strlen(rhs.seq))   //Create a dynamic seq.
{
    for(int i=0 ; i<int(strlen(rhs.seq)) ; i++) //Copy the content of rhs.seq into our seq.
        seq[i] = rhs.seq[i];
}

//----->> Destructor <<-----------
DNA::~DNA()
{
    delete[] seq;   // Delete seq from heap.
}

//----->> Operator + overloading <<-----------
DNA DNA::operator + (DNA& rhs)
{
    int length = int(strlen(seq));
    int length2 = int(strlen(rhs.seq));

    DNA dna_obj;
    dna_obj.seq = new char[length+length2];

    for(int i=0 ; i<length ; i++)
    {
        dna_obj.seq[i] = seq[i];
    }
    for(int i=length ; i<(length+length2) ; i++)
    {
        dna_obj.seq[i] = rhs.seq[i-length];
    }
    dna_obj.seq[length+length2] = '\0';

    return dna_obj;
}

//----->> Deep copy <<-----------
void DNA::operator= (const DNA& rhs)
{
    seq = new char[strlen(rhs.seq)];
    strcpy(seq, rhs.seq);
}

//----->> Operator == overloading <<-----------
bool operator ==(DNA& obj1, DNA& obj2)
{
    if(strlen(obj1.seq) != strlen(obj2.seq))
    {
        return false;
    }
    for(int i=0 ; i<int(strlen(obj1.seq)) ; i++)
    {
        if(obj1.seq[i] != obj2.seq[i])
        {
            return false;
        }
    }
    return true;
}

//----->> Operator != overloading <<-----------
bool operator !=(DNA& obj1, DNA& obj2)
{
    if(strlen(obj1.seq) != strlen(obj2.seq))
    {
        return true;
    }
    for(int i=0 ; i<int(strlen(obj1.seq)) ; i++)
    {
        if(obj1.seq[i] != obj2.seq[i])
        {
            return true;
        }
    }
    return false;
}

//----->> Operator >> overloading <<-----------
istream & operator >> (istream& in, DNA& dna_obj)
{
    in >> dna_obj.seq;
    return in;  // To enable cascading.
}

//----->> Operator << overloading <<-----------
ostream& operator << (ostream& out, DNA& dna_obj)
{
    out << dna_obj.seq;
    return out;
}

//----->> Print the sequence <<-----------
void DNA::Print()
{
    for(int i=0 ; i<int (strlen(seq)) ; i++)
        cout << seq[i];
    cout << endl;
}

//----->> Read sequence from file <<-----------
void DNA::read_from_file(string file_name)
{
    string strand;
    ifstream file(file_name.c_str());
    if(!file)
        cout << "Error loading the file\n";
    else
    {
        while(file >> strand)
        {
            seq = new char[strand.size()];
            for(int i=0 ; i<int(strand.size()) ; i++)
                seq[i] = strand[i];
            seq[strand.size()] = '\0';
            break;
        }
    }
    file.close();
}

//----->> Print sequence in file <<-----------
void DNA::print_in_file(string file_name)
{
    ofstream file(file_name.c_str());
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        file << seq[i];
    file.close();
}

//----->> Function to produce RNA sequence <<-----------
RNA DNA::ConvertToRNA()
{
    RNA rna_obj;
    for(int i=0 ; i<int(strlen(seq)) ; i++)
    {
        if(seq[i] == 'T')   //Replace every 'T' by 'U' to convert.
        {
            rna_obj.seq[i] = 'U';
        }
        else
        {
            rna_obj.seq[i] = seq[i];
        }
    }
    rna_obj.seq[strlen(seq)] = '\0';

    return rna_obj;
}

//----->> Convert to protein << -----------
Protein DNA::ConvertToProtein()
{
    CodonsTable CodonsTable_obj;
    Protein protein_obj;
    RNA rna_obj;
    rna_obj = ConvertToRNA();
    protein_obj = rna_obj.ConvertToProtein(CodonsTable_obj);
    return protein_obj;
}

//----->> Function to produce DNA complementary sequence << -----------
void DNA::BuildComplementaryStrand()
{
    for(int i=0 ; i<int(strlen(seq)) ; i++) // Replace 'T' by 'A' , 'G' by 'C' and visa verse.
    {
        if(seq[i] == 'T')
            seq[i] = 'A';
        else if(seq[i] == 'A')
            seq[i] = 'T';
        else if(seq[i] == 'C')
            seq[i] = 'G';
        else if(seq[i] == 'G')
            seq[i] = 'C';
    }
}
