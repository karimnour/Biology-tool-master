#include "Sequence.h"

#include <iostream>
using namespace std;

//----- >> Default constructor << -----------
Sequence::Sequence()
{
    seq = new char[50];
}

//----- >> Parameterized constructor << -----------
Sequence::Sequence(int length)
{
    seq = new char[length+1];
    seq[length] = '\0';
}

//----- >> Shallow copy << -----------
Sequence::Sequence(const Sequence & rhs)
{
    seq = new char [strlen(rhs.seq)];
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        seq[i] = rhs.seq[i];
}

//----- >> LCS align << -----------
int Align(Sequence& s1, Sequence&  s2)
{
    int LCS[strlen(s1.seq)+1][strlen(s2.seq)+1];
    int i, j;
    for (i=0 ; i<= int(strlen(s1.seq)) ; i++)
    {
        for (j=0 ; j<= int(strlen(s2.seq)) ; j++)
        {
            if (i == 0 || j == 0)
                LCS[i][j] = 0;

            else if (s1.seq[i-1] == s2.seq[j-1])
                LCS[i][j] = LCS[i-1][j-1] + 1;

            else
                LCS[i][j] = max(LCS[i-1][j], LCS[i][j-1]);
        }
    }
    return LCS[strlen(s1.seq)][strlen(s2.seq)];
}

//----- >> Destructor << -----------
Sequence::~Sequence()
{
    delete []seq;   //Delete the seq.
}

//----- >> Deep copy << -----------
void Sequence::operator = (const Sequence& rhs)
{
    seq = new char [strlen(rhs.seq)];
    for(int i=0 ; i<int(strlen(rhs.seq)) ; i++)
        seq = rhs.seq;
}
