#include "Protein.h"

#include <iostream>

using namespace std;

//----->> Default constructor <<-----------
Protein::Protein()
{
    seq = new char[50];
}

//----->> Parameterized constructor <<----------
Protein::Protein(char * seq)
:Sequence(strlen(seq))
{
    for(int i=0 ; i<int((strlen(seq))) ; i++)
        this->seq[i] = seq[i];
}

//------->> Parameterized constructor <<-----------
Protein::Protein(char * seq, Protein_Type atype)
:Sequence(strlen(seq))
{
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        this->seq[i] = seq[i];
    type = atype;
}

//----->> Destructor <<-----------
Protein::~Protein()
{
    delete[] seq;
}

//----->> Operator + overloading <<-----------
Protein Protein::operator + (Protein& rhs)
{
    int length = int(strlen(seq));
    int length2 = int(strlen(rhs.seq));

    Protein protein_obj;
    protein_obj.seq = new char[length+length2];

    for(int i=0 ; i<length ; i++)
    {
        protein_obj.seq[i] = seq[i];
    }
    for(int i=length ; i<(length+length2) ; i++)
    {
        protein_obj.seq[i] = rhs.seq[i-length];
    }
    protein_obj.seq[length+length2] = '\0';

    return protein_obj;
}

//----->> Deep copy <<-----------
void Protein::operator= (const Protein& rhs)
{
    seq = new char[strlen(rhs.seq)];
    strcpy(seq, rhs.seq);
}

//----->> Operator == overloading <<-----------
bool operator ==(Protein& obj1, Protein& obj2)
{
    if(strlen(obj1.seq) != strlen(obj2.seq))
    {
        return false;
    }
    for(int i=0 ; i<int(strlen(obj1.seq)) ; i++)
    {
        if(obj1.seq[i] != obj2.seq[i])
        {
            return false;
        }
    }
    return true;
}

//----->> Operator != overloading <<-----------
bool operator !=(Protein& obj1, Protein& obj2)
{
    if(strlen(obj1.seq) != strlen(obj2.seq))
    {
        return true;
    }
    for(int i=0 ; i<int(strlen(obj1.seq)) ; i++)
    {
        if(obj1.seq[i] != obj2.seq[i])
        {
            return true;
        }
    }
    return false;
}

//----->> Operator >> overloading <<-----------
istream & operator >> (istream& in, Protein& protein_obj)
{
    in >> protein_obj.seq;
    return in;  // To enable cascading.
}

//----->> Operator << overloading <<-----------
ostream& operator << (ostream& out, Protein& protein_obj)
{
    out << protein_obj.seq;
    return out;
}

//----- >> Print Protein sequence << ----------
void Protein::Print()
{
    for(int i=0 ; i<int (strlen(seq)) ; i++)
        cout << seq[i];
    cout << endl;
}

//----->> Read sequence from file <<-----------
void Protein::read_from_file(string file_name)
{
    string strand;
    ifstream file(file_name.c_str());
    if(!file)
        cout << "Error loading the file\n";
    else
    {
        while(file >> strand)
        {
            seq = new char[strand.size()];
            for(int i=0 ; i<int(strand.size()) ; i++)
                seq[i] = strand[i];
            seq[strand.size()] = '\0';
            break;
        }
    }
    file.close();
}

//----->> Print sequence in file <<-----------
void Protein::print_in_file(string file_name)
{
    ofstream file(file_name.c_str());
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        file << seq[i];
    file.close();
}
