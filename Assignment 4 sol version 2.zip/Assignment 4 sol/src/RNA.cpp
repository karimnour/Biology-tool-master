#include "RNA.h"
#include "Sequence.h"
#include "CodonsTable.h"
#include "Protein.h"
#include <iostream>
#include <cstring>

using namespace std;

class CodonsTable;

//----->> Default constructor <<-----------
RNA::RNA()
{
    seq = new char[50];
}

//----->> Parameterized constructor <<----------
RNA::RNA(char * seq)
:Sequence(strlen(seq))
{
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        this->seq[i] = seq[i];
}

//------->> Parameterized constructor <<-----------
RNA::RNA(char * seq, RNA_Type atype)
:Sequence(strlen(seq))
{
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        this->seq[i] = seq[i];
    type = atype;
}

//----->> Copy constructor <<-----------
RNA::RNA(const RNA& rhs)
:Sequence(strlen(rhs.seq))  //Create a dynamic seq.
{
    for(int i=0 ; i<int(strlen(rhs.seq)) ; i++) //Copy the content of rhs.seq into our seq.
        seq[i] = rhs.seq[i];
}

//----->> Destructor <<-----------
RNA::~RNA()
{
    delete[] seq;
}

//----->> Operator + overloading <<-----------
RNA RNA::operator + (RNA& rhs)
{
    int length = int(strlen(seq));
    int length2 = int(strlen(rhs.seq));

    RNA rna_obj;
    rna_obj.seq = new char[length+length2];

    for(int i=0 ; i<length ; i++)
    {
        rna_obj.seq[i] = seq[i];
    }
    for(int i=length ; i<(length+length2) ; i++)
    {
        rna_obj.seq[i] = rhs.seq[i-length];
    }
    rna_obj.seq[length+length2] = '\0';

    return rna_obj;
}

//----->> Deep copy <<-----------
void RNA::operator= (const RNA& rhs)
{
    seq = new char[strlen(rhs.seq)];
    strcpy(seq, rhs.seq);
}

//----->> Operator == overloading <<-----------
bool operator ==(RNA& obj1, RNA& obj2)
{
    if(strlen(obj1.seq) != strlen(obj2.seq))
    {
        return false;
    }
    for(int i=0 ; i<int(strlen(obj1.seq)) ; i++)
    {
        if(obj1.seq[i] != obj2.seq[i])
        {
            return false;
        }
    }
    return true;
}

//----->> Operator != overloading <<-----------
bool operator !=(RNA& obj1, RNA& obj2)
{
    if(strlen(obj1.seq) != strlen(obj2.seq))
    {
        return true;
    }
    for(int i=0 ; i<int(strlen(obj1.seq)) ; i++)
    {
        if(obj1.seq[i] != obj2.seq[i])
        {
            return true;
        }
    }
    return false;
}

//----->> Operator >> overloading <<-----------
istream & operator >> (istream& in, RNA& rna_obj)
{
    in >> rna_obj.seq;
    return in;  // To enable cascading.
}

//----->> Operator << overloading <<-----------
ostream& operator << (ostream& out, RNA& rna_obj)
{
    out << rna_obj.seq;
    return out;
}

//----- >> Print RNA sequence << ----------
void RNA::Print()
{
    for(int i=0 ; i<int (strlen(seq)) ; i++)
        cout << seq[i];
    cout << endl;
}

//----->> Read sequence from file <<-----------
void RNA::read_from_file(string file_name)
{
    string strand;
    ifstream file(file_name.c_str());
    if(!file)
        cout << "Error loading the file\n";
    else
    {
        while(file >> strand)
        {
            seq = new char[strand.size()];
            for(int i=0 ; i<int(strand.size()) ; i++)
                seq[i] = strand[i];
            seq[strand.size()] = '\0';
            break;
        }
    }
    file.close();
}

//----->> Print sequence in file <<-----------
void RNA::print_in_file(string file_name)
{
    ofstream file(file_name.c_str());
    for(int i=0 ; i<int(strlen(seq)) ; i++)
        file << seq[i];
    file.close();
}

//----->> Function to produce DNA sequence <<-----------
DNA RNA::ConvertToDNA()
{
    DNA dob;
    for(int i=0 ; i<int(strlen(seq)) ; i++)
    {
        if(seq[i] == 'U')
            dob.seq[i] = 'T';
        else
            dob.seq[i] = seq[i];
    }
    dob.seq[strlen(seq)] = '\0';

    return dob;
}

//----->> Function to produce Protein sequence <<-----------
Protein RNA::ConvertToProtein(CodonsTable & table)    //I want to make the parameter const, so I will alse make the function loadfromfile const, but it doesn't work.
{
    table.LoadCodonsFromFile("RNA_codon_table.txt");
    Protein p_obj;
    char * value = new char[4];
    Codon temp;
    p_obj.seq = new char[50];
    int y = 0;

    for(int i=0 ; i<int(strlen(seq)) ; i+=3)
    {
        value[0] = seq[i];
        value[1] = seq[i+1];
        value[2] = seq[i+2];
        value[3] = '\0';

        temp = table.getAminoAcid(value);
        p_obj.seq[y] = temp.AminoAcid;
        y++;
    }
    return p_obj;
}
