#include <iostream>
#include "Sequence.h"
#include "DNA.h"
#include "RNA.h"
#include "Protein.h"
#include "CodonsTable.h"

using namespace std;

int main()
{
    int choose;
    string filename;

    DNA dna_obj;
    RNA rna_obj;
    Protein protein_obj;
    CodonsTable codonsTable_obj;

    cout << "\n\n-------- >> BIO program <<-----------\n\n";

    while(true)
    {
        HomePage:
        cout << "Choose\n";
        cout << "1- Input DNA sequence\n";
        cout << "2- Input RNA sequence\n";
        cout << "3- Input Protein sequence\n";
        cout << "0- END\n\n";
        cin >> choose;
        cout << endl;


//--------------------------- >> DNA << ---------------------------------------
        if(choose == 1)
        {
            //----- >> Enter the sequence << -----------
            cout << "Choose\n";
            cout << "1- Enter the sequence\n";
            cout << "2- Load the sequence from a file\n";
            cout << endl;
            cin >> choose;
            cout << endl;

            if(choose == 1)    //Enter the sequence manually.
            {
                cout << "Enter the sequence\n";
                cin >> dna_obj;
                cout << endl << endl;
            }

            else if (choose == 2)       //Enter the sequence from a file.
            {
                cout << "Enter the file name\n";
                cin >> filename;
                dna_obj.read_from_file(filename);
                cout << endl << endl;
            }

            while(true)
            {
                //----- >> Functions on the DNA << -----------
                cout << "Choose what to do\n";
                cout << "1 -check equality with another strand\n";
                cout << "2 -check non equality with another strand\n";
                cout << "3 -Add to another strand\n";
                cout << "4 -Print the sequence on the screen\n";
                cout << "5 -Print the sequence on a file\n";
                cout << "6- Convert to RNA sequence\n";
                cout << "7- Convert to Protein sequence\n";
                cout << "8- Build complementary strand\n";
                cout << "9 -Back to the Home Page\n";
                cout << "0 -END\n\n";
                cin >> choose;
                if(choose == 1)     //check equality with another strand.
                {
                    cout << endl;
                    DNA dna_obj2;
                    cout << "Enter the second strand\n";
                    cin >> dna_obj2;
                    cout << endl;
                    if((dna_obj == dna_obj2))
                    {
                        cout << "Yes, they are equal. \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                    else
                    {
                        cout << "No, they are not equal! \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                }

                if(choose == 2)     //check non equality with another strand.
                {
                    cout << endl;
                    DNA dna_obj2;
                    cout << "Enter the second strand\n";
                    cin >> dna_obj2;
                    cout << endl;
                    if((dna_obj != dna_obj2))
                    {
                        cout << "Yes, they are not equal. \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                    else
                    {
                        cout << "No, they are equal! \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                }

                if(choose == 3)     //Add to another strand.
                {
                    cout << endl;
                    DNA dna_obj2;
                    DNA dna_obj3;
                    cout << "Enter the second strand\n";
                    cin >> dna_obj2;
                    cout << endl;
                    dna_obj3 = (dna_obj + dna_obj2);
                    dna_obj3.Print();
                }

                else if(choose == 4)    //Print the sequence on the screen.
                {
                    cout << "Your DNA sequence is: ";
                    cout << dna_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;
                }

                else if(choose == 5)    //Print the sequence on a file.
                {
                    cout << "Enter the file name\n";
                    cin >> filename;
                    cout << endl;
                    dna_obj.print_in_file(filename.c_str());
                }

                else if(choose == 6)    //Convert to RNA sequence
                {
                    rna_obj = dna_obj.ConvertToRNA();
                    cout << "Your RNA sequence is: ";
                    cout << rna_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;
                }

                else if(choose == 7)
                {
                    protein_obj = dna_obj.ConvertToProtein();
                    cout << "Your Protein sequence is: ";
                    cout << protein_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;
                }

                else if(choose == 8)
                {
                    dna_obj.BuildComplementaryStrand();
                    cout << "Your complementary Strand is: ";
                    cout << dna_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;

                }

                else if(choose == 9)    //Back to the Home Page.
                {
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    goto HomePage;
                }

                else if(choose == 0)    //END the program.
                    return 0;
            }

        }


//--------------------------- >> RNA << ---------------------------------------
        if(choose == 2)
        {
            //----- >> Enter the sequence << -----------
            cout << "Choose\n";
            cout << "1- Enter the sequence\n";
            cout << "2- Load the sequence from a file\n";
            cout << endl;
            cin >> choose;
            cout << endl;

            if(choose == 1)    //Enter the sequence manually.
            {
                cout << "Enter the sequence\n";
                cin >> rna_obj;
                cout << endl << endl;
            }

            else if (choose == 2)       //Enter the sequence from a file.
            {
                cout << "Enter the file name\n";
                cin >> filename;
                rna_obj.read_from_file(filename);
                cout << endl << endl;
            }

            while(true)
            {
                //----- >> Functions on the RNA << -----------
                cout << "Choose what to do\n";
                cout << "1 -check equality with another sequence\n";
                cout << "2 -check non equality with another sequence\n";
                cout << "3 -Add to another sequence\n";
                cout << "4 -Print the sequence on the screen\n";
                cout << "5 -Print the sequence on a file\n";
                cout << "6- Convert to DNA sequence\n";
                cout << "7- Convert to protein\n";
                cout << "8 -Back to the Home Page\n";
                cout << "0 -END\n\n";
                cin >> choose;
                if(choose == 1)     //check equality with another sequence.
                {
                    cout << endl;
                    RNA rna_obj2;
                    cout << "Enter the second sequence\n";
                    cin >> rna_obj2;
                    cout << endl;
                    if((rna_obj == rna_obj2))
                    {
                        cout << "Yes, they are equal. \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                    else
                    {
                        cout << "No, they are not equal! \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                }

                if(choose == 2)     //check non equality with another sequence.
                {
                    cout << endl;
                    RNA rna_obj2;
                    cout << "Enter the second sequence\n";
                    cin >> rna_obj2;
                    cout << endl;
                    if((rna_obj != rna_obj2))
                    {
                        cout << "Yes, they are not equal. \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                    else
                    {
                        cout << "No, they are equal! \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                }

                if(choose == 3)     //Add to another sequence.
                {
                    cout << endl;
                    RNA rna_obj2;
                    RNA rna_obj3;
                    cout << "Enter the second sequence\n";
                    cin >> rna_obj2;
                    cout << endl;
                    rna_obj3 = (rna_obj + rna_obj2);
                    rna_obj3.Print();
                }

                else if(choose == 4)    //Print the sequence on the screen.
                {
                    cout << "Your RNA sequence is: ";
                    cout << rna_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;
                }

                else if(choose == 5)    //Print the sequence on a file.
                {
                    cout << "Enter the file name\n";
                    cin >> filename;
                    cout << endl;
                    rna_obj.print_in_file(filename.c_str());
                }

                else if(choose == 6)    //Convert to DNA sequence.
                {
                    dna_obj = rna_obj.ConvertToDNA();
                    cout << "Your DNA sequence is: ";
                    cout << dna_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;
                }

                else if(choose == 7)    //Convert to Protein sequence.
                {
                    protein_obj = rna_obj.ConvertToProtein(codonsTable_obj);
                    cout << "Your Protein sequence is: ";
                    cout << protein_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;
                }

                else if(choose == 8)    //Back to the Home Page.
                {
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    goto HomePage;
                }

                else if(choose == 0)    //END the program.
                    return 0;
            }
        }

//--------------------------- >> Protein << ---------------------------------------
        if(choose == 3)
        {
            //----- >> Enter the sequence << -----------
            cout << "Choose\n";
            cout << "1- Enter the sequence\n";
            cout << "2- Load the sequence from a file\n";
            cout << endl;
            cin >> choose;
            cout << endl;

            if(choose == 1)    //Enter the sequence manually.
            {
                cout << "Enter the sequence\n";
                cin >> protein_obj;
                cout << endl << endl;
            }

            else if (choose == 2)       //Enter the sequence from a file.
            {
                cout << "Enter the file name\n";
                cin >> filename;
                protein_obj.read_from_file(filename);
                cout << endl << endl;
            }

            while(true)
            {
                //----- >> Functions on the Protein << -----------
                cout << "Choose what to do\n";
                cout << "1 -check equality with another sequence\n";
                cout << "2 -check non equality with another sequence\n";
                cout << "3 -Add to another sequence\n";
                cout << "4 -Print the sequence on the screen\n";
                cout << "5 -Print the sequence on a file\n";
                cout << "6 -Back to the Home Page\n";
                cout << "0 -END\n\n";
                cin >> choose;
                if(choose == 1)     //check equality with another sequence.
                {
                    cout << endl;
                    Protein protein_obj2;
                    cout << "Enter the second sequence\n";
                    cin >> protein_obj2;
                    cout << endl;
                    if((protein_obj == protein_obj2))
                    {
                        cout << "Yes, they are equal. \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                    else
                    {
                        cout << "No, they are not equal! \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                }

                if(choose == 2)     //check non equality with another sequence.
                {
                    cout << endl;
                    Protein protein_obj2;
                    cout << "Enter the second sequence\n";
                    cin >> protein_obj2;
                    cout << endl;
                    if((protein_obj != protein_obj2))
                    {
                        cout << "Yes, they are not equal. \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                    else
                    {
                        cout << "No, they are equal! \n\n";
                        cout << "-------------*_*----------------" << endl;
                        cout << endl;
                    }
                }

                if(choose == 3)     //Add to another sequence.
                {
                    cout << endl;
                    Protein protein_obj2;
                    Protein protein_obj3;
                    cout << "Enter the second sequence\n";
                    cin >> protein_obj2;
                    cout << endl;
                    protein_obj3 = (protein_obj + protein_obj2);
                    protein_obj3.Print();
                }

                else if(choose == 4)    //Print the sequence on the screen.
                {
                    cout << "Your Protein sequence is: ";
                    cout << protein_obj;
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    cout << endl;
                }

                else if(choose == 5)    //Print the sequence on a file.
                {
                    cout << "Enter the file name\n";
                    cin >> filename;
                    cout << endl;
                    protein_obj.print_in_file(filename.c_str());
                }

                else if(choose == 6)    //Back to the Home Page.
                {
                    cout << endl;
                    cout << "-------------*_*----------------" << endl;
                    goto HomePage;
                }

                else if(choose == 0)    //END the program.
                    return 0;
            }
        }


        else if(choose == 0)
            return 0;
    }
    /*
    invalid sequence exception
*/
    return 0;
}
